# Code Citations

## License: unknown
https://github.com/freyhill/freyhill.github.io/tree/93ff85076768e97a60b21dd49bebd8a681a5a912/example/currying/index.html

```
.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"
```


## License: unknown
https://github.com/xJupiterx/QRCode-Attendance-Monitoring-Using-HTML-CSS-JS-PHP-MYSQL/tree/a24ed1b42c44d88e786087d1eff503ac3991289b/progcoor-page.php

```
>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Admin Dashboard</
```

